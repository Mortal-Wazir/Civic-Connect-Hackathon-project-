-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to award coins for new issues
CREATE OR REPLACE FUNCTION public.award_coins_for_issue()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.profiles
  SET coins = coins + 10
  WHERE id = NEW.user_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to award coins when issue is created
DROP TRIGGER IF EXISTS on_issue_created ON public.issues;
CREATE TRIGGER on_issue_created
  AFTER INSERT ON public.issues
  FOR EACH ROW EXECUTE FUNCTION public.award_coins_for_issue();

-- Function to hide issues with multiple flags
CREATE OR REPLACE FUNCTION public.check_issue_flags()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.issues
  SET is_hidden = TRUE
  WHERE id = NEW.issue_id
  AND (SELECT COUNT(*) FROM public.issue_flags WHERE issue_id = NEW.issue_id) >= 3;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to check flags
DROP TRIGGER IF EXISTS on_issue_flagged ON public.issue_flags;
CREATE TRIGGER on_issue_flagged
  AFTER INSERT ON public.issue_flags
  FOR EACH ROW EXECUTE FUNCTION public.check_issue_flags();
