-- Create sample issues for testing (optional)
-- This will only work after you have authenticated users

-- First, let's create some sample data that doesn't require authentication
-- We'll create a dummy profile for demo purposes

-- Insert a demo user profile (you can delete this later)
INSERT INTO public.profiles (id, email, full_name, coins) 
VALUES (
  '00000000-0000-0000-0000-000000000000',
  'demo@example.com',
  'Demo User',
  50
) ON CONFLICT (id) DO NOTHING;

-- Insert sample issues around New York City
INSERT INTO public.issues (
  user_id,
  title,
  description,
  category_id,
  latitude,
  longitude,
  address,
  status
) VALUES
  (
    '00000000-0000-0000-0000-000000000000',
    'Large pothole on Main Street',
    'There is a large pothole that has been growing for weeks. It is causing damage to vehicles and is dangerous for cyclists.',
    1, -- Pothole category
    40.7589,
    -73.9851,
    'Main Street, New York, NY',
    'open'
  ),
  (
    '00000000-0000-0000-0000-000000000000',
    'Overflowing garbage bin',
    'The garbage bin at the corner has been overflowing for several days. It is attracting pests and creating an unsanitary condition.',
    2, -- Garbage category
    40.7614,
    -73.9776,
    'Corner of 5th Ave and E 42nd St, New York, NY',
    'open'
  ),
  (
    '00000000-0000-0000-0000-000000000000',
    'Broken street light',
    'The street light has been out for over a week, making this area very dark and unsafe at night.',
    3, -- Street Light category
    40.7505,
    -73.9934,
    'Broadway, New York, NY',
    'open'
  ),
  (
    '00000000-0000-0000-0000-000000000000',
    'Malfunctioning traffic signal',
    'The traffic light is stuck on red in one direction, causing major traffic delays during rush hour.',
    4, -- Traffic Signal category
    40.7580,
    -73.9855,
    'Times Square, New York, NY',
    'in_progress'
  ),
  (
    '00000000-0000-0000-0000-000000000000',
    'Water leak on sidewalk',
    'There is a continuous water leak creating a puddle and potentially wasting a lot of water.',
    5, -- Water Issue category
    40.7549,
    -73.9840,
    '7th Ave, New York, NY',
    'open'
  )
ON CONFLICT DO NOTHING;
