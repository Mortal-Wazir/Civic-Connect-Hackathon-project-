// Install Leaflet and React-Leaflet dependencies
const { execSync } = require("child_process")

console.log("Installing Leaflet and React-Leaflet dependencies...")

try {
  // Install the main dependencies
  execSync("npm install leaflet@^1.9.4 react-leaflet@^4.2.1", { stdio: "inherit" })

  console.log("✅ Successfully installed leaflet and react-leaflet")

  // Install TypeScript types for development
  execSync("npm install --save-dev @types/leaflet@^1.9.8", { stdio: "inherit" })

  console.log("✅ Successfully installed @types/leaflet for TypeScript support")

  console.log("\n🎉 All Leaflet dependencies have been installed successfully!")
  console.log("\nNext steps:")
  console.log("1. The map component is ready to use with OpenStreetMap")
  console.log("2. No API keys required - completely free!")
  console.log("3. Set up your Supabase environment variables")
  console.log("4. Run the database scripts to create tables")
} catch (error) {
  console.error("❌ Error installing dependencies:", error.message)
  console.log("\nTry running these commands manually:")
  console.log("npm install leaflet@^1.9.4 react-leaflet@^4.2.1")
  console.log("npm install --save-dev @types/leaflet@^1.9.8")
}
