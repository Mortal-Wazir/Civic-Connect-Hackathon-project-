-- Insert default categories
INSERT INTO public.categories (name, icon, color) VALUES
  ('Pothole', '🕳️', '#ef4444'),
  ('Garbage', '🗑️', '#f97316'),
  ('Street Light', '💡', '#eab308'),
  ('Traffic Signal', '🚦', '#22c55e'),
  ('Water Issue', '💧', '#3b82f6'),
  ('Graffiti', '🎨', '#8b5cf6'),
  ('Broken Sidewalk', '🚶', '#6b7280'),
  ('Other', '❓', '#64748b')
ON CONFLICT DO NOTHING;
