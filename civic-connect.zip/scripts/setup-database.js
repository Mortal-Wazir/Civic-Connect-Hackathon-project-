// Automated database setup script
const { createClient } = require("@supabase/supabase-js")

const supabaseUrl = "https://rdnmkvmgdbakulwopvuj.supabase.co"
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJkbm1rdm1nZGJha3Vsd29wdnVqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQxMTE4MjAsImV4cCI6MjA2OTY4NzgyMH0.ik9MAKZ2DNU4wU6g2ZM99ubMM7FD82f2K87QLj-v5rA"

const supabase = createClient(supabaseUrl, supabaseKey)

async function setupDatabase() {
  console.log("🚀 Setting up Civic Connect database...")

  try {
    // Test connection
    console.log("📡 Testing Supabase connection...")
    const { data, error } = await supabase.from("profiles").select("count").limit(1)

    if (error && error.code === "42P01") {
      console.log("✅ Connection successful! Tables need to be created.")
    } else if (!error) {
      console.log("✅ Connection successful! Some tables already exist.")
    } else {
      console.error("❌ Connection failed:", error.message)
      return
    }

    console.log("\n📋 Next steps:")
    console.log("1. Go to your Supabase project: https://supabase.com/dashboard/project/rdnmkvmgdbakulwopvuj")
    console.log("2. Navigate to SQL Editor")
    console.log("3. Run these scripts in order:")
    console.log("   - scripts/001_create_tables.sql")
    console.log("   - scripts/002_seed_categories.sql")
    console.log("   - scripts/003_create_functions.sql")
    console.log("   - scripts/004_create_sample_data.sql (optional)")
    console.log("\n4. Create Storage Bucket:")
    console.log("   - Go to Storage section")
    console.log('   - Create new bucket named "images"')
    console.log("   - Make it public")
    console.log("\n5. Enable Authentication:")
    console.log("   - Go to Authentication > Settings")
    console.log("   - Enable Google OAuth (optional)")
    console.log("   - Configure email settings")

    console.log("\n🎉 Your Supabase project is ready for setup!")
  } catch (error) {
    console.error("❌ Setup failed:", error.message)
  }
}

setupDatabase()
