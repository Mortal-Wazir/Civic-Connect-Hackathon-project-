"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle, Database, Play, ExternalLink } from "lucide-react"
import { supabase } from "@/lib/supabase"

interface DatabaseStatus {
  profiles: boolean
  categories: boolean
  issues: boolean
  categoriesSeeded: boolean
  storageConfigured: boolean
}

export function DatabaseStatus() {
  const [status, setStatus] = useState<DatabaseStatus>({
    profiles: false,
    categories: false,
    issues: false,
    categoriesSeeded: false,
    storageConfigured: false,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkDatabaseStatus()
  }, [])

  const checkDatabaseStatus = async () => {
    setLoading(true)
    const newStatus: DatabaseStatus = {
      profiles: false,
      categories: false,
      issues: false,
      categoriesSeeded: false,
      storageConfigured: false,
    }

    try {
      // Check profiles table
      const { error: profilesError } = await supabase.from("profiles").select("id").limit(1)
      newStatus.profiles = !profilesError
      console.log("Profiles table:", newStatus.profiles, profilesError?.message)

      // Check categories table
      const { data: categoriesData, error: categoriesError } = await supabase.from("categories").select("id").limit(1)
      newStatus.categories = !categoriesError
      newStatus.categoriesSeeded = (categoriesData?.length || 0) > 0
      console.log(
        "Categories table:",
        newStatus.categories,
        "Seeded:",
        newStatus.categoriesSeeded,
        categoriesError?.message,
      )

      // Check issues table
      const { error: issuesError } = await supabase.from("issues").select("id").limit(1)
      newStatus.issues = !issuesError
      console.log("Issues table:", newStatus.issues, issuesError?.message)

      // Check storage configuration with detailed logging
      try {
        console.log("Checking storage buckets...")
        const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets()
        console.log("Buckets response:", { buckets, error: bucketsError })

        if (bucketsError) {
          console.error("Buckets error:", bucketsError)
        }

        const imagesBucket = buckets?.find((bucket) => bucket.id === "images")
        console.log("Images bucket found:", imagesBucket)

        newStatus.storageConfigured = !!imagesBucket && imagesBucket.public
        console.log("Storage configured:", newStatus.storageConfigured)
      } catch (error) {
        console.error("Storage check failed:", error)
        newStatus.storageConfigured = false
      }
    } catch (error) {
      console.error("Error checking database status:", error)
    }

    console.log("Final status:", newStatus)
    setStatus(newStatus)
    setLoading(false)
  }

  const allTablesExist = status.profiles && status.categories && status.issues
  const isReady = allTablesExist && status.categoriesSeeded && status.storageConfigured

  if (loading) {
    return (
      <Card className="mb-6 bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <Database className="h-8 w-8 animate-spin mx-auto mb-2 text-blue-600" />
            <p className="text-gray-600 dark:text-gray-300">Checking database status...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (isReady) {
    return null // Don't show anything if database is ready
  }

  return (
    <Card className="mb-6 border-amber-200 dark:border-amber-800 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-amber-800 dark:text-amber-200">
          <AlertCircle className="h-5 w-5" />
          Database Setup Required
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-start gap-3 p-4 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-amber-200 dark:border-amber-700">
          <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900 rounded-full flex items-center justify-center flex-shrink-0">
            <Database className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <p className="font-medium text-amber-900 dark:text-amber-100 mb-1">Setup Required</p>
            <p className="text-sm text-amber-700 dark:text-amber-300">
              The database tables and storage need to be configured before you can use Civic Connect.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h4 className="font-semibold text-sm text-gray-900 dark:text-gray-100 flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              Database Tables
            </h4>
            <div className="space-y-2">
              {[
                { name: "Profiles", status: status.profiles },
                { name: "Categories", status: status.categories },
                { name: "Issues", status: status.issues },
              ].map((table) => (
                <div
                  key={table.name}
                  className="flex items-center gap-3 p-2 bg-white/30 dark:bg-gray-800/30 rounded-md"
                >
                  {table.status ? (
                    <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-red-500 dark:text-red-400" />
                  )}
                  <span className="text-sm font-medium text-gray-900 dark:text-gray-100">{table.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-sm text-gray-900 dark:text-gray-100 flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              Configuration
            </h4>
            <div className="space-y-2">
              <div className="flex items-center gap-3 p-2 bg-white/30 dark:bg-gray-800/30 rounded-md">
                {status.categoriesSeeded ? (
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-500 dark:text-red-400" />
                )}
                <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Categories Seeded</span>
              </div>
              <div className="flex items-center gap-3 p-2 bg-white/30 dark:bg-gray-800/30 rounded-md">
                {status.storageConfigured ? (
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-500 dark:text-red-400" />
                )}
                <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Image Storage (50MB)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 p-6 rounded-xl border border-blue-200 dark:border-blue-800">
          <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-3 flex items-center gap-2">
            <Play className="h-4 w-4" />
            Setup Instructions
          </h4>
          <ol className="text-sm space-y-2 list-decimal list-inside text-blue-800 dark:text-blue-200 mb-4">
            <li>Go to your Supabase project dashboard</li>
            <li>Navigate to the SQL Editor</li>
            <li>
              Run these scripts in order:
              <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                <li>001_create_tables.sql</li>
                <li>002_seed_categories.sql</li>
                <li>003_create_functions.sql</li>
                <li>
                  <strong>005_fix_storage_policies.sql</strong> (creates bucket + fixes image upload)
                </li>
              </ul>
            </li>
            <li>The storage bucket will be created automatically</li>
          </ol>
          <div className="flex gap-2">
            <Button
              onClick={() => window.open("https://supabase.com/dashboard/project/rdnmkvmgdbakulwopvuj", "_blank")}
              variant="outline"
              className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 border-blue-300 dark:border-blue-600 text-blue-800 dark:text-blue-200"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open Supabase Dashboard
            </Button>
          </div>
        </div>

        <Button
          onClick={checkDatabaseStatus}
          variant="outline"
          className="w-full bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 border-amber-300 dark:border-amber-600 text-amber-800 dark:text-amber-200"
        >
          <Play className="h-4 w-4 mr-2" />
          Recheck Database Status
        </Button>
      </CardContent>
    </Card>
  )
}
