"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Camera, MapPin, Upload, X, Loader2, Sparkles, AlertCircle } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { supabase } from "@/lib/supabase"
import { uploadImage } from "@/lib/storage"
import { toast } from "@/hooks/use-toast"
import { Map } from "./map"

interface Category {
  id: number
  name: string
  icon: string
  color: string
}

interface ReportIssueDialogProps {
  children: React.ReactNode
  userLocation: [number, number] | null
  onIssueReported?: () => void
}

export function ReportIssueDialog({ children, userLocation, onIssueReported }: ReportIssueDialogProps) {
  const { user } = useAuth()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [uploadingImage, setUploadingImage] = useState(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [selectedLocation, setSelectedLocation] = useState<[number, number] | null>(null)
  const [isSelectingLocation, setIsSelectingLocation] = useState(false)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    categoryId: "",
  })

  const handleOpenChange = async (newOpen: boolean) => {
    if (newOpen && !user) {
      toast({
        title: "Login required",
        description: "Please log in to report issues.",
        variant: "destructive",
      })
      return
    }

    setOpen(newOpen)

    if (newOpen) {
      // Fetch categories when dialog opens
      const { data } = await supabase.from("categories").select("*").order("name")
      setCategories(data || [])
      setSelectedLocation(userLocation)
    } else {
      // Reset form when dialog closes
      setFormData({ title: "", description: "", categoryId: "" })
      setImageFile(null)
      setImagePreview(null)
      setSelectedLocation(null)
      setIsSelectingLocation(false)
    }
  }

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !selectedLocation) return

    setLoading(true)

    try {
      let imageUrl = null

      if (imageFile) {
        setUploadingImage(true)
        const uploadResult = await uploadImage(imageFile)
        setUploadingImage(false)

        if (uploadResult.error) {
          toast({
            title: "Image upload failed",
            description: "Continuing without image...",
            variant: "destructive",
          })
        } else {
          imageUrl = uploadResult.url
        }
      }

      const { error } = await supabase.from("issues").insert({
        user_id: user.id,
        title: formData.title,
        description: formData.description,
        category_id: Number.parseInt(formData.categoryId),
        latitude: selectedLocation[1],
        longitude: selectedLocation[0],
        image_url: imageUrl,
      })

      if (error) throw error

      toast({
        title: "🎉 Issue reported successfully!",
        description: "Thank you for helping improve our community. You earned 10 coins!",
      })

      setOpen(false)
      onIssueReported?.()
    } catch (error: any) {
      console.error("Error reporting issue:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to report issue. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      setUploadingImage(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent
        className="max-w-5xl max-h-[95vh] overflow-hidden z-[99999] bg-white dark:bg-gray-900 border-2 border-gray-200 dark:border-gray-700 shadow-2xl"
        style={{ zIndex: 99999 }}
      >
        {/* Header Section */}
        <DialogHeader className="pb-6 border-b-2 border-gray-100 dark:border-gray-800 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 -m-6 mb-0 p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-xl">
              <AlertCircle className="w-8 h-8 text-white" />
            </div>
            <div>
              <DialogTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Report a Civic Issue
              </DialogTitle>
              <p className="text-gray-600 dark:text-gray-300 mt-2 text-lg">
                Help improve your community by reporting local issues
              </p>
            </div>
          </div>
        </DialogHeader>

        {/* Content Section */}
        <div className="overflow-y-auto max-h-[calc(95vh-140px)] bg-white dark:bg-gray-900">
          <form onSubmit={handleSubmit} className="space-y-8 p-6">
            {/* Image Upload Section */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Camera className="w-6 h-6 text-blue-600" />
                <Label className="text-xl font-bold text-gray-900 dark:text-white">Photo Evidence</Label>
                <span className="text-lg text-gray-500 dark:text-gray-400">(Optional)</span>
              </div>

              <div className="relative">
                {imagePreview ? (
                  <div className="relative group">
                    <div className="relative overflow-hidden rounded-3xl shadow-2xl border-4 border-gray-200 dark:border-gray-700">
                      <img
                        src={imagePreview || "/placeholder.svg"}
                        alt="Preview"
                        className="w-full h-72 object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
                    </div>
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-4 right-4 rounded-full w-12 h-12 p-0 shadow-xl hover:scale-110 transition-transform duration-200 bg-red-500 hover:bg-red-600"
                      onClick={() => {
                        setImageFile(null)
                        setImagePreview(null)
                      }}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                    {uploadingImage && (
                      <div className="absolute inset-0 bg-black/80 flex items-center justify-center rounded-3xl backdrop-blur-sm">
                        <div className="text-white text-center">
                          <Loader2 className="h-16 w-16 animate-spin mx-auto mb-4" />
                          <p className="text-xl font-bold">Uploading image...</p>
                          <p className="text-lg opacity-90">Please wait</p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <Card className="border-4 border-dashed border-blue-300 dark:border-blue-600 hover:border-blue-500 dark:hover:border-blue-400 transition-all duration-300 bg-blue-50 dark:bg-blue-950/50">
                    <CardContent className="flex flex-col items-center justify-center py-16">
                      <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-8 shadow-2xl">
                        <Camera className="h-12 w-12 text-white" />
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900 border-2 border-blue-300 dark:border-blue-600 text-blue-700 dark:text-blue-300 font-bold px-10 py-4 text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
                      >
                        <Upload className="h-6 w-6 mr-3" />
                        Choose Photo
                      </Button>
                      <p className="text-gray-600 dark:text-gray-300 mt-6 text-center text-lg">
                        Take a photo to help others understand the issue better
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Any image file supported</p>
                    </CardContent>
                  </Card>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="*/*"
                  capture="environment"
                  onChange={handleImageSelect}
                  className="hidden"
                />
              </div>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              {/* Left Column */}
              <div className="space-y-8">
                {/* Title */}
                <div className="space-y-4">
                  <Label
                    htmlFor="title"
                    className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-3"
                  >
                    <Sparkles className="w-6 h-6 text-yellow-500" />
                    Issue Title
                  </Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Large pothole on Main Street"
                    required
                    className="h-14 text-lg rounded-2xl border-2 border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400 transition-all duration-300 bg-white dark:bg-gray-800"
                  />
                </div>

                {/* Category */}
                <div className="space-y-4">
                  <Label className="text-xl font-bold text-gray-900 dark:text-white">Category</Label>
                  <Select
                    value={formData.categoryId}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, categoryId: value }))}
                    required
                  >
                    <SelectTrigger className="h-14 text-lg rounded-2xl border-2 border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400 bg-white dark:bg-gray-800">
                      <SelectValue placeholder="Select issue category" />
                    </SelectTrigger>
                    <SelectContent className="z-[999999] bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 shadow-2xl">
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id.toString()} className="py-3">
                          <div className="flex items-center gap-4 py-1">
                            <span className="text-2xl">{category.icon}</span>
                            <span className="font-semibold text-lg">{category.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-8">
                {/* Description */}
                <div className="space-y-4">
                  <Label htmlFor="description" className="text-xl font-bold text-gray-900 dark:text-white">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                    placeholder="Provide detailed information about the issue, its impact, and any relevant context..."
                    rows={8}
                    required
                    className="text-lg rounded-2xl border-2 border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400 transition-all duration-300 resize-none bg-white dark:bg-gray-800"
                  />
                </div>
              </div>
            </div>

            {/* Location Section */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MapPin className="w-6 h-6 text-green-600" />
                  <Label className="text-xl font-bold text-gray-900 dark:text-white">Location</Label>
                </div>
                <Button
                  type="button"
                  variant={isSelectingLocation ? "default" : "outline"}
                  size="lg"
                  onClick={() => setIsSelectingLocation(!isSelectingLocation)}
                  className={`rounded-2xl font-bold px-8 py-3 text-lg transition-all duration-300 ${
                    isSelectingLocation
                      ? "bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-xl"
                      : "hover:bg-green-50 dark:hover:bg-green-900 border-2 border-green-300 dark:border-green-600 text-green-700 dark:text-green-300 bg-white dark:bg-gray-800"
                  }`}
                >
                  <MapPin className="h-5 w-5 mr-2" />
                  {isSelectingLocation ? "Done Selecting" : "Select on Map"}
                </Button>
              </div>

              <Card className="overflow-hidden rounded-3xl shadow-2xl border-4 border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                <div className="h-96 relative">
                  <Map
                    onIssueSelect={() => {}}
                    selectedIssue={null}
                    userLocation={selectedLocation}
                    onLocationSelect={(lat, lng) => setSelectedLocation([lng, lat])}
                    isSelecting={isSelectingLocation}
                  />
                  {isSelectingLocation && (
                    <div className="absolute top-6 left-6 z-[1000]">
                      <Card className="bg-green-500 text-white border-0 shadow-2xl">
                        <CardContent className="p-4">
                          <p className="text-lg font-bold">📍 Click on the map to select location</p>
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </div>
              </Card>

              {selectedLocation && (
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900 dark:to-emerald-900 p-6 rounded-2xl border-2 border-green-200 dark:border-green-700">
                  <p className="text-green-800 dark:text-green-200 font-bold text-lg">
                    📍 Selected location: {selectedLocation[1].toFixed(6)}, {selectedLocation[0].toFixed(6)}
                  </p>
                </div>
              )}
            </div>

            {/* Submit Section */}
            <div className="flex gap-6 pt-8 border-t-2 border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                className="flex-1 h-16 text-xl font-bold rounded-2xl border-2 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-300 bg-white dark:bg-gray-800"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={loading || !selectedLocation || uploadingImage}
                className="flex-1 h-16 text-xl font-bold rounded-2xl bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white shadow-2xl hover:shadow-3xl transition-all duration-300 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-6 w-6 mr-3 animate-spin" />
                    Reporting Issue...
                  </>
                ) : uploadingImage ? (
                  <>
                    <Loader2 className="h-6 w-6 mr-3 animate-spin" />
                    Uploading Photo...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-6 w-6 mr-3" />
                    Report Issue & Earn 10 Coins
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}
