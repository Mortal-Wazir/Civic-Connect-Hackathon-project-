"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { IssueCard } from "./issue-card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface Issue {
  id: string
  title: string
  description: string
  latitude: number
  longitude: number
  image_url: string | null
  status: string
  upvotes: number
  categories: {
    name: string
    icon: string
    color: string
  }
  profiles: {
    full_name: string
    avatar_url?: string
  }
  created_at: string
}

interface IssueListProps {
  userLocation: [number, number] | null
  onIssueSelect: (issue: Issue) => void
  selectedIssue: Issue | null
}

export function IssueList({ userLocation, onIssueSelect, selectedIssue }: IssueListProps) {
  const [issues, setIssues] = useState<Issue[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<string>("all")
  const [categories, setCategories] = useState<any[]>([])

  useEffect(() => {
    fetchCategories()
  }, [])

  useEffect(() => {
    if (userLocation) {
      fetchNearbyIssues()
    }
  }, [userLocation, filter])

  const fetchCategories = async () => {
    const { data } = await supabase.from("categories").select("*").order("name")

    setCategories(data || [])
  }

  const fetchNearbyIssues = async () => {
    if (!userLocation) return

    setLoading(true)
    try {
      const [lng, lat] = userLocation

      // Calculate bounding box for ~5km radius
      const latDelta = 0.045
      const lngDelta = 0.045

      // Check if tables exist first
      const { data: categoriesExist, error: categoriesError } = await supabase.from("categories").select("id").limit(1)

      if (categoriesError) {
        console.log("Database tables not yet created. Please run the setup scripts first.")
        setIssues([])
        setLoading(false)
        return
      }

      // Fetch issues
      let issuesQuery = supabase
        .from("issues")
        .select(`
          id,
          title,
          description,
          latitude,
          longitude,
          image_url,
          status,
          upvotes,
          created_at,
          category_id,
          user_id
        `)
        .gte("latitude", lat - latDelta)
        .lte("latitude", lat + latDelta)
        .gte("longitude", lng - lngDelta)
        .lte("longitude", lng + lngDelta)
        .eq("is_hidden", false)

      if (filter !== "all") {
        if (filter === "open") {
          issuesQuery = issuesQuery.eq("status", "open")
        } else {
          // For category filters, we'll filter after fetching
        }
      }

      const { data: issuesData, error: issuesError } = await issuesQuery.order("created_at", { ascending: false })

      if (issuesError) {
        console.error("Error fetching issues:", issuesError)
        setIssues([])
        setLoading(false)
        return
      }

      // Fetch categories and profiles separately
      const { data: categories } = await supabase.from("categories").select("*")
      const { data: profiles } = await supabase.from("profiles").select("*")

      // Manually join the data
      let issuesWithRelations = (issuesData || []).map((issue) => {
        const category = categories?.find((cat) => cat.id === issue.category_id)
        const profile = profiles?.find((prof) => prof.id === issue.user_id)

        return {
          ...issue,
          categories: category || { name: "Unknown", icon: "❓", color: "#64748b" },
          profiles: profile || { full_name: "Anonymous", avatar_url: null },
        }
      })

      // Apply category filter if needed
      if (filter !== "all" && filter !== "open") {
        issuesWithRelations = issuesWithRelations.filter((issue) => issue.categories.name === filter)
      }

      setIssues(issuesWithRelations)
    } catch (error) {
      console.error("Error fetching issues:", error)
      setIssues([])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">Nearby Issues</h2>
          <Badge variant="secondary">{issues.length} found</Badge>
        </div>

        <div className="flex gap-2 flex-wrap">
          <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}>
            All
          </Button>
          <Button variant={filter === "open" ? "default" : "outline"} size="sm" onClick={() => setFilter("open")}>
            Open
          </Button>
          {categories.slice(0, 3).map((category) => (
            <Button
              key={category.id}
              variant={filter === category.name ? "default" : "outline"}
              size="sm"
              onClick={() => setFilter(category.name)}
            >
              {category.icon} {category.name}
            </Button>
          ))}
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading nearby issues...</div>
          ) : issues.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No issues found in your area.</div>
          ) : (
            issues.map((issue) => (
              <IssueCard
                key={issue.id}
                issue={issue}
                onSelect={() => onIssueSelect(issue)}
                isSelected={selectedIssue?.id === issue.id}
              />
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
