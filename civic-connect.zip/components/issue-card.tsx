"use client"

import type React from "react"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MapPin, Clock, Flag, ThumbsUp, Eye, Sparkles } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/lib/auth"
import { toast } from "@/hooks/use-toast"

interface Issue {
  id: string
  title: string
  description: string
  latitude: number
  longitude: number
  image_url: string | null
  status: string
  upvotes: number
  categories: {
    name: string
    icon: string
    color: string
  }
  profiles: {
    full_name: string
    avatar_url?: string
  }
  created_at: string
}

interface IssueCardProps {
  issue: Issue
  onSelect?: () => void
  isSelected?: boolean
}

export function IssueCard({ issue, onSelect, isSelected }: IssueCardProps) {
  const { user } = useAuth()
  const [upvoted, setUpvoted] = useState(false)
  const [upvoteCount, setUpvoteCount] = useState(issue.upvotes)
  const [flagging, setFlagging] = useState(false)

  const handleUpvote = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!user) {
      toast({
        title: "Login required",
        description: "Please log in to upvote issues.",
        variant: "destructive",
      })
      return
    }

    try {
      if (upvoted) {
        await supabase.from("issue_upvotes").delete().eq("issue_id", issue.id).eq("user_id", user.id)
        setUpvoted(false)
        setUpvoteCount((prev) => prev - 1)
      } else {
        await supabase.from("issue_upvotes").insert({ issue_id: issue.id, user_id: user.id })
        setUpvoted(true)
        setUpvoteCount((prev) => prev + 1)
      }
    } catch (error) {
      console.error("Error upvoting:", error)
      toast({
        title: "Error",
        description: "Failed to upvote issue.",
        variant: "destructive",
      })
    }
  }

  const handleFlag = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!user) {
      toast({
        title: "Login required",
        description: "Please log in to flag issues.",
        variant: "destructive",
      })
      return
    }

    setFlagging(true)
    try {
      await supabase.from("issue_flags").insert({
        issue_id: issue.id,
        user_id: user.id,
        reason: "inappropriate",
      })

      toast({
        title: "Issue flagged",
        description: "Thank you for helping keep our community safe.",
      })
    } catch (error) {
      console.error("Error flagging:", error)
      toast({
        title: "Error",
        description: "Failed to flag issue.",
        variant: "destructive",
      })
    } finally {
      setFlagging(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-gradient-to-r from-red-500 to-pink-500 text-white"
      case "in_progress":
        return "bg-gradient-to-r from-yellow-500 to-orange-500 text-white"
      case "resolved":
        return "bg-gradient-to-r from-green-500 to-emerald-500 text-white"
      case "closed":
        return "bg-gradient-to-r from-gray-500 to-slate-500 text-white"
      default:
        return "bg-gradient-to-r from-gray-500 to-slate-500 text-white"
    }
  }

  const getPriorityRing = (status: string) => {
    switch (status) {
      case "open":
        return "ring-red-500/30"
      case "in_progress":
        return "ring-yellow-500/30"
      case "resolved":
        return "ring-green-500/30"
      default:
        return "ring-gray-500/30"
    }
  }

  return (
    <Card
      className={`cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 card-gradient group ${
        isSelected ? "ring-2 ring-primary shadow-xl scale-[1.02]" : ""
      } ${getPriorityRing(issue.status)} ring-1`}
      onClick={onSelect}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3 flex-1">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-lg group-hover:scale-110 transition-transform duration-300"
              style={{
                background: `linear-gradient(135deg, ${issue.categories.color}20, ${issue.categories.color}40)`,
                color: issue.categories.color,
                border: `2px solid ${issue.categories.color}30`,
              }}
            >
              {issue.categories.icon}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground leading-tight group-hover:text-primary transition-colors duration-300">
                {issue.title}
              </h3>
              <Badge className={`mt-2 font-semibold px-3 py-1 rounded-full ${getStatusColor(issue.status)} shadow-sm`}>
                {issue.status.replace("_", " ").toUpperCase()}
              </Badge>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleUpvote}
              className={`h-8 px-3 rounded-xl transition-all duration-300 ${
                upvoted
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg"
                  : "hover:bg-blue-50 dark:hover:bg-blue-950 text-muted-foreground hover:text-blue-600"
              }`}
            >
              <ThumbsUp className="h-3 w-3 mr-1" />
              <span className="font-semibold">{upvoteCount}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleFlag}
              disabled={flagging}
              className="h-8 px-3 rounded-xl text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950 transition-all duration-300"
            >
              <Flag className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0 space-y-4">
        {issue.image_url && (
          <div className="relative overflow-hidden rounded-xl group-hover:scale-[1.02] transition-transform duration-300">
            <img src={issue.image_url || "/placeholder.svg"} alt={issue.title} className="w-full h-40 object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
            <div className="absolute top-3 right-3">
              <Button size="sm" variant="secondary" className="glass text-white border-white/20 hover:bg-white/20">
                <Eye className="h-3 w-3 mr-1" />
                View
              </Button>
            </div>
          </div>
        )}

        <p className="text-muted-foreground leading-relaxed line-clamp-2 group-hover:text-foreground transition-colors duration-300">
          {issue.description}
        </p>

        <div className="flex items-center justify-between pt-2 border-t border-border/50">
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8 ring-2 ring-white dark:ring-gray-800 shadow-sm">
              <AvatarImage src={issue.profiles.avatar_url || "/placeholder.svg"} className="object-cover" />
              <AvatarFallback className="bg-gradient-to-br from-primary to-purple-600 text-white font-bold text-xs">
                {issue.profiles.full_name?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-sm text-foreground">{issue.profiles.full_name || "Anonymous"}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                <span>Nearby</span>
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
              <Clock className="h-3 w-3" />
              <span>{formatDistanceToNow(new Date(issue.created_at), { addSuffix: true })}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-primary">
              <Sparkles className="h-3 w-3" />
              <span className="font-semibold">+10 coins</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
