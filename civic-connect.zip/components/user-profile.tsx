"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Coins, Trophy, Calendar, LogOut } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { supabase } from "@/lib/supabase"
import { formatDistanceToNow } from "date-fns"

interface UserIssue {
  id: string
  title: string
  description: string
  status: string
  image_url: string | null
  created_at: string
  categories: {
    name: string
    icon: string
    color: string
  }
}

interface LeaderboardUser {
  id: string
  full_name: string
  avatar_url: string | null
  coins: number
}

export function UserProfile({ children }: { children: React.ReactNode }) {
  const { user, profile, signOut } = useAuth()
  const [userIssues, setUserIssues] = useState<UserIssue[]>([])
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([])
  const [loading, setLoading] = useState(false)

  const fetchUserIssues = async () => {
    if (!user) return

    const { data } = await supabase
      .from("issues")
      .select(`
        *,
        categories (name, icon, color)
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    setUserIssues(data || [])
  }

  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from("profiles")
      .select("id, full_name, avatar_url, coins")
      .order("coins", { ascending: false })
      .limit(10)

    setLeaderboard(data || [])
  }

  const handleOpenChange = (open: boolean) => {
    if (open) {
      setLoading(true)
      Promise.all([fetchUserIssues(), fetchLeaderboard()]).finally(() => {
        setLoading(false)
      })
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-100 text-red-800"
      case "in_progress":
        return "bg-yellow-100 text-yellow-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (!user) return null

  return (
    <Dialog onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Profile</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Profile Header */}
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} />
              <AvatarFallback className="text-lg">
                {profile?.full_name?.charAt(0) || user.email?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="text-xl font-semibold">{profile?.full_name || "Anonymous User"}</h3>
              <p className="text-gray-600">{user.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                  <Coins className="h-3 w-3 mr-1" />
                  {profile?.coins || 0} coins
                </Badge>
              </div>
            </div>
            <Button variant="outline" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>

          <Tabs defaultValue="issues" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="issues">My Issues</TabsTrigger>
              <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
            </TabsList>

            <TabsContent value="issues" className="space-y-4">
              <ScrollArea className="h-96">
                {loading ? (
                  <div className="text-center py-8 text-gray-500">Loading your issues...</div>
                ) : userIssues.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">You haven't reported any issues yet.</div>
                ) : (
                  <div className="space-y-3">
                    {userIssues.map((issue) => (
                      <Card key={issue.id}>
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2">
                              <span style={{ color: issue.categories.color }} className="text-lg">
                                {issue.categories.icon}
                              </span>
                              <div>
                                <CardTitle className="text-sm">{issue.title}</CardTitle>
                                <Badge variant="secondary" className={getStatusColor(issue.status)}>
                                  {issue.status.replace("_", " ")}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <Calendar className="h-3 w-3" />
                              {formatDistanceToNow(new Date(issue.created_at), { addSuffix: true })}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          {issue.image_url && (
                            <img
                              src={issue.image_url || "/placeholder.svg"}
                              alt={issue.title}
                              className="w-full h-24 object-cover rounded mb-2"
                            />
                          )}
                          <p className="text-sm text-gray-600 line-clamp-2">{issue.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>

            <TabsContent value="leaderboard" className="space-y-4">
              <ScrollArea className="h-96">
                {loading ? (
                  <div className="text-center py-8 text-gray-500">Loading leaderboard...</div>
                ) : (
                  <div className="space-y-3">
                    {leaderboard.map((user, index) => (
                      <Card key={user.id} className={index < 3 ? "border-yellow-200 bg-yellow-50" : ""}>
                        <CardContent className="flex items-center gap-3 p-4">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 text-sm font-semibold">
                            {index === 0 && <Trophy className="h-4 w-4 text-yellow-500" />}
                            {index === 1 && <Trophy className="h-4 w-4 text-gray-400" />}
                            {index === 2 && <Trophy className="h-4 w-4 text-amber-600" />}
                            {index > 2 && <span>{index + 1}</span>}
                          </div>
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={user.avatar_url || undefined} />
                            <AvatarFallback>{user.full_name?.charAt(0) || "U"}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-medium">{user.full_name || "Anonymous"}</p>
                          </div>
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                            <Coins className="h-3 w-3 mr-1" />
                            {user.coins}
                          </Badge>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
