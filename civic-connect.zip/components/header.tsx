"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ModeToggle } from "@/components/mode-toggle"
import { Plus, Coins, User, Sparkles, MapPin } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { AuthDialog } from "./auth-dialog"
import { UserProfile } from "./user-profile"
import { ReportIssueDialog } from "./report-issue-dialog"

interface HeaderProps {
  userLocation: [number, number] | null
  onIssueReported?: () => void
}

export function Header({ userLocation, onIssueReported }: HeaderProps) {
  const { user, profile } = useAuth()
  const [authDialogOpen, setAuthDialogOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        {/* Logo Section */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 bg-gradient-to-br from-primary via-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg animate-pulse-glow">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-background animate-pulse"></div>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Civic Connect
            </h1>
            <p className="text-xs text-muted-foreground font-medium tracking-wide">
              Building Better Communities Together
            </p>
          </div>
        </div>

        {/* Actions Section */}
        <div className="flex items-center gap-3">
          <ModeToggle />

          {user ? (
            <>
              {/* Report Issue Button */}
              <ReportIssueDialog userLocation={userLocation} onIssueReported={onIssueReported}>
                <Button className="btn-primary text-white font-semibold px-6 py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group">
                  <Plus className="h-4 w-4 mr-2 group-hover:rotate-90 transition-transform duration-300" />
                  <span className="hidden sm:inline">Report Issue</span>
                  <span className="sm:hidden">Report</span>
                </Button>
              </ReportIssueDialog>

              {/* Coins Badge */}
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold px-4 py-2 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group">
                <Coins className="h-4 w-4 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                <span className="text-sm">{profile?.coins || 0}</span>
                <Sparkles className="h-3 w-3 ml-1 opacity-80" />
              </Badge>

              {/* User Profile */}
              <UserProfile>
                <Button variant="ghost" className="p-2 rounded-xl hover:bg-accent/50 transition-all duration-300 group">
                  <Avatar className="h-10 w-10 ring-2 ring-primary/20 group-hover:ring-primary/40 transition-all duration-300">
                    <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} className="object-cover" />
                    <AvatarFallback className="bg-gradient-to-br from-primary to-purple-600 text-white font-bold text-sm">
                      {profile?.full_name?.charAt(0) || user.email?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </UserProfile>
            </>
          ) : (
            <Button
              onClick={() => setAuthDialogOpen(true)}
              className="btn-primary text-white font-semibold px-6 py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              <User className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform duration-300" />
              <span className="hidden sm:inline">Get Started</span>
              <span className="sm:hidden">Sign In</span>
            </Button>
          )}
        </div>
      </div>

      <AuthDialog open={authDialogOpen} onOpenChange={setAuthDialogOpen} />
    </header>
  )
}
