"use client"

import { useEffect, useState, useRef } from "react"
import { supabase } from "@/lib/supabase"

interface Issue {
  id: string
  title: string
  description: string
  latitude: number
  longitude: number
  image_url: string | null
  status: string
  categories: {
    name: string
    icon: string
    color: string
  }
  profiles: {
    full_name: string
  }
  created_at: string
}

interface MapProps {
  onIssueSelect: (issue: Issue | null) => void
  selectedIssue: Issue | null
  userLocation: [number, number] | null
  onLocationSelect?: (lat: number, lng: number) => void
  isSelecting?: boolean
}

export function Map({ onIssueSelect, selectedIssue, userLocation, onLocationSelect, isSelecting }: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])
  const [issues, setIssues] = useState<Issue[]>([])
  const [selectedLocation, setSelectedLocation] = useState<[number, number] | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  // Initialize map
  useEffect(() => {
    if (!mapRef.current || !userLocation || isLoaded) return

    const initializeMap = async () => {
      try {
        // Dynamically import Leaflet
        const L = await import("leaflet")

        // Fix for default markers
        delete (L.Icon.Default.prototype as any)._getIconUrl
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
          iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
          shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
        })

        // Create map
        const map = L.map(mapRef.current).setView([userLocation[1], userLocation[0]], 13)

        // Add OpenStreetMap tiles
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(map)

        // Add user location marker
        const userIcon = L.divIcon({
          html: `
            <div style="
              width: 16px;
              height: 16px;
              border-radius: 50%;
              background: #3b82f6;
              border: 3px solid white;
              box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            "></div>
          `,
          className: "user-location-marker",
          iconSize: [16, 16],
          iconAnchor: [8, 8],
        })

        L.marker([userLocation[1], userLocation[0]], { icon: userIcon }).addTo(map).bindPopup("Your Location")

        // Handle map clicks for location selection
        map.on("click", (e: any) => {
          if (isSelecting && onLocationSelect) {
            const { lat, lng } = e.latlng
            setSelectedLocation([lat, lng])
            onLocationSelect(lat, lng)

            // Add selection marker
            if (mapInstanceRef.current?.selectionMarker) {
              map.removeLayer(mapInstanceRef.current.selectionMarker)
            }

            const selectionIcon = L.divIcon({
              html: `
                <div style="
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: #ef4444;
                  border: 3px solid white;
                  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                  animation: pulse 2s infinite;
                "></div>
                <style>
                  @keyframes pulse {
                    0% { transform: scale(1); opacity: 1; }
                    50% { transform: scale(1.2); opacity: 0.7; }
                    100% { transform: scale(1); opacity: 1; }
                  }
                </style>
              `,
              className: "selection-marker",
              iconSize: [20, 20],
              iconAnchor: [10, 10],
            })

            mapInstanceRef.current.selectionMarker = L.marker([lat, lng], { icon: selectionIcon })
              .addTo(map)
              .bindPopup(`Selected Location<br/>${lat.toFixed(6)}, ${lng.toFixed(6)}`)
          }
        })

        // Change cursor when selecting
        if (isSelecting) {
          mapRef.current.style.cursor = "crosshair"
        } else {
          mapRef.current.style.cursor = ""
        }

        mapInstanceRef.current = { map, L }
        setIsLoaded(true)
      } catch (error) {
        console.error("Error initializing map:", error)
      }
    }

    initializeMap()

    return () => {
      if (mapInstanceRef.current?.map) {
        mapInstanceRef.current.map.remove()
        mapInstanceRef.current = null
        setIsLoaded(false)
      }
    }
  }, [userLocation, isSelecting, onLocationSelect])

  // Fetch issues near user location
  useEffect(() => {
    if (!userLocation) return

    const fetchNearbyIssues = async () => {
      try {
        const [lng, lat] = userLocation

        // Calculate bounding box for ~5km radius
        const latDelta = 0.045 // ~5km
        const lngDelta = 0.045 // ~5km

        // First check if tables exist by trying a simple query
        const { data: categoriesExist, error: categoriesError } = await supabase
          .from("categories")
          .select("id")
          .limit(1)

        if (categoriesError) {
          console.log("Database tables not yet created. Please run the setup scripts first.")
          return
        }

        const { data: issuesExist, error: issuesError } = await supabase.from("issues").select("id").limit(1)

        if (issuesError) {
          console.log("Issues table not yet created. Please run the setup scripts first.")
          return
        }

        // Now fetch the actual data with proper joins
        const { data, error } = await supabase
          .from("issues")
          .select(`
            id,
            title,
            description,
            latitude,
            longitude,
            image_url,
            status,
            created_at,
            category_id,
            user_id
          `)
          .gte("latitude", lat - latDelta)
          .lte("latitude", lat + latDelta)
          .gte("longitude", lng - lngDelta)
          .lte("longitude", lng + lngDelta)
          .eq("is_hidden", false)
          .order("created_at", { ascending: false })

        if (error) {
          console.error("Error fetching issues:", error)
          return
        }

        // Fetch categories separately
        const { data: categories } = await supabase.from("categories").select("*")

        // Fetch profiles separately
        const { data: profiles } = await supabase.from("profiles").select("*")

        // Manually join the data
        const issuesWithRelations = (data || []).map((issue) => {
          const category = categories?.find((cat) => cat.id === issue.category_id)
          const profile = profiles?.find((prof) => prof.id === issue.user_id)

          return {
            ...issue,
            categories: category || { name: "Unknown", icon: "❓", color: "#64748b" },
            profiles: profile || { full_name: "Anonymous" },
          }
        })

        setIssues(issuesWithRelations)
      } catch (error) {
        console.error("Error in fetchNearbyIssues:", error)
        // Set empty array on error to prevent crashes
        setIssues([])
      }
    }

    fetchNearbyIssues()
  }, [userLocation])

  // Add issue markers
  useEffect(() => {
    if (!mapInstanceRef.current || !issues.length) return

    const { map, L } = mapInstanceRef.current

    // Clear existing markers
    markersRef.current.forEach((marker) => map.removeLayer(marker))
    markersRef.current = []

    // Add new markers
    issues.forEach((issue) => {
      const customIcon = L.divIcon({
        html: `
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: ${issue.categories.color};
            border: 3px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
            transition: transform 0.2s;
          " 
          onmouseover="this.style.transform='scale(1.1)'"
          onmouseout="this.style.transform='scale(1)'"
          >
            ${issue.categories.icon}
          </div>
        `,
        className: "custom-marker",
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      })

      const popupContent = `
        <div style="padding: 8px; min-width: 200px;">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
            <span style="color: ${issue.categories.color}; font-size: 18px;">${issue.categories.icon}</span>
            <h3 style="font-weight: 600; font-size: 14px; margin: 0;">${issue.title}</h3>
          </div>
          ${issue.image_url ? `<img src="${issue.image_url}" alt="${issue.title}" style="width: 100%; height: 96px; object-fit: cover; border-radius: 4px; margin-bottom: 8px;" />` : ""}
          <p style="font-size: 12px; color: #666; margin: 0 0 8px 0;">${issue.description}</p>
          <p style="font-size: 12px; color: #999; margin: 0;">Reported by ${issue.profiles.full_name || "Anonymous"}</p>
        </div>
      `

      const marker = L.marker([issue.latitude, issue.longitude], { icon: customIcon })
        .addTo(map)
        .bindPopup(popupContent)
        .on("click", () => onIssueSelect(issue))

      markersRef.current.push(marker)
    })
  }, [issues, onIssueSelect])

  // Fly to selected issue
  useEffect(() => {
    if (!selectedIssue || !mapInstanceRef.current) return

    const { map } = mapInstanceRef.current
    map.flyTo([selectedIssue.latitude, selectedIssue.longitude], 16, {
      duration: 1,
    })
  }, [selectedIssue])

  if (!userLocation) {
    return <div className="w-full h-full flex items-center justify-center bg-gray-100">Loading map...</div>
  }

  return (
    <>
      <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        crossOrigin=""
      />
      <div ref={mapRef} className="w-full h-full" style={{ minHeight: "400px" }} />
    </>
  )
}
