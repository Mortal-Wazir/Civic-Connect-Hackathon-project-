"use client"

import { supabase } from "./supabase"

export interface UploadResult {
  url: string | null
  error: string | null
}

export async function uploadImage(file: File): Promise<UploadResult> {
  try {
    // Check if user is authenticated
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return { url: null, error: "Please sign in to upload images" }
    }

    // Simple filename - just timestamp + original extension
    const fileExt = file.name.split(".").pop() || "jpg"
    const fileName = `${Date.now()}.${fileExt}`

    // Upload the file as-is
    const { data, error: uploadError } = await supabase.storage.from("images").upload(fileName, file, {
      cacheControl: "3600",
      upsert: false,
    })

    if (uploadError) {
      console.error("Upload error:", uploadError)
      return { url: null, error: "Failed to upload image" }
    }

    // Get public URL
    const { data: urlData } = supabase.storage.from("images").getPublicUrl(fileName)

    return { url: urlData.publicUrl, error: null }
  } catch (error: any) {
    console.error("Upload error:", error)
    return { url: null, error: "Upload failed" }
  }
}

export async function deleteImage(url: string): Promise<{ success: boolean; error: string | null }> {
  try {
    // Extract filename from URL
    const urlParts = url.split("/")
    const fileName = urlParts[urlParts.length - 1]

    const { error } = await supabase.storage.from("images").remove([fileName])

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true, error: null }
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to delete image" }
  }
}
