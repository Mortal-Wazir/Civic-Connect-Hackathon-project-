import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string | null
          full_name: string | null
          avatar_url: string | null
          coins: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email?: string | null
          full_name?: string | null
          avatar_url?: string | null
          coins?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string | null
          full_name?: string | null
          avatar_url?: string | null
          coins?: number
          created_at?: string
          updated_at?: string
        }
      }
      categories: {
        Row: {
          id: number
          name: string
          icon: string
          color: string
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          icon: string
          color: string
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          icon?: string
          color?: string
          created_at?: string
        }
      }
      issues: {
        Row: {
          id: string
          user_id: string
          title: string
          description: string
          category_id: number
          latitude: number
          longitude: number
          address: string | null
          image_url: string | null
          status: "open" | "in_progress" | "resolved" | "closed"
          upvotes: number
          flag_count: number
          is_hidden: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          description: string
          category_id: number
          latitude: number
          longitude: number
          address?: string | null
          image_url?: string | null
          status?: "open" | "in_progress" | "resolved" | "closed"
          upvotes?: number
          flag_count?: number
          is_hidden?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          description?: string
          category_id?: number
          latitude?: number
          longitude?: number
          address?: string | null
          image_url?: string | null
          status?: "open" | "in_progress" | "resolved" | "closed"
          upvotes?: number
          flag_count?: number
          is_hidden?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
