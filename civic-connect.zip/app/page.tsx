"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Map } from "@/components/map"
import { IssueList } from "@/components/issue-list"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, Loader2, Sparkles, Users, TrendingUp, Shield, Zap, Award, Globe } from "lucide-react"
import { DatabaseStatus } from "@/components/database-status"

interface Issue {
  id: string
  title: string
  description: string
  latitude: number
  longitude: number
  image_url: string | null
  status: string
  upvotes: number
  categories: {
    name: string
    icon: string
    color: string
  }
  profiles: {
    full_name: string
    avatar_url?: string
  }
  created_at: string
}

export default function HomePage() {
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null)
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null)
  const [locationLoading, setLocationLoading] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)

  useEffect(() => {
    requestLocation()
  }, [])

  const requestLocation = () => {
    setLocationLoading(true)
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation([position.coords.longitude, position.coords.latitude])
          setLocationLoading(false)
        },
        (error) => {
          console.error("Error getting location:", error)
          // Default to New York City if location access is denied
          setUserLocation([-74.006, 40.7128])
          setLocationLoading(false)
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000, // 5 minutes
        },
      )
    } else {
      // Default to New York City if geolocation is not supported
      setUserLocation([-74.006, 40.7128])
      setLocationLoading(false)
    }
  }

  const handleIssueReported = () => {
    setRefreshKey((prev) => prev + 1)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/30 via-white to-purple-50/30 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800">
      <Header userLocation={userLocation} onIssueReported={handleIssueReported} />
      <DatabaseStatus />

      <main className="container mx-auto px-4 py-8">
        {!userLocation ? (
          <div className="flex items-center justify-center min-h-[70vh]">
            <Card className="max-w-2xl mx-auto bg-gradient-to-br from-white via-blue-50/50 to-purple-50/50 dark:from-gray-900 dark:via-blue-950/30 dark:to-purple-950/30 shadow-2xl border-0">
              <CardContent className="flex flex-col items-center justify-center py-20 px-12">
                {locationLoading ? (
                  <div className="text-center space-y-8">
                    <div className="relative">
                      <div className="w-32 h-32 bg-gradient-to-br from-blue-500 via-purple-600 to-pink-600 rounded-full flex items-center justify-center animate-pulse-glow shadow-2xl">
                        <MapPin className="w-16 h-16 text-white animate-float" />
                      </div>
                      <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-xl">
                        <Loader2 className="h-8 w-8 animate-spin text-white" />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                        Finding Your Location
                      </h3>
                      <p className="text-xl text-muted-foreground text-center leading-relaxed max-w-lg">
                        We're locating you to show nearby civic issues and help you make a positive impact in your
                        community.
                      </p>
                    </div>
                    <div className="flex items-center gap-3 text-lg text-muted-foreground">
                      <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                      <span className="font-medium">Securing your location...</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-center space-y-8">
                    <div className="relative">
                      <div className="w-32 h-32 bg-gradient-to-br from-red-500 via-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-2xl animate-pulse-glow">
                        <MapPin className="w-16 h-16 text-white" />
                      </div>
                      <div className="absolute -top-2 -right-2 w-12 h-12 bg-red-500 rounded-full flex items-center justify-center shadow-xl">
                        <span className="text-white text-2xl font-bold">!</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-4xl font-bold text-foreground">Location Access Required</h3>
                      <p className="text-xl text-muted-foreground text-center leading-relaxed max-w-2xl">
                        To show you nearby civic issues and help you report problems in your area, we need access to
                        your location. Your privacy is protected and location data stays secure.
                      </p>
                    </div>
                    <Button
                      onClick={requestLocation}
                      className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white font-bold px-12 py-4 text-xl rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                    >
                      <MapPin className="h-6 w-6 mr-3" />
                      Enable Location Access
                    </Button>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 max-w-2xl">
                      <div className="flex flex-col items-center gap-3 p-4 bg-white/50 dark:bg-gray-800/50 rounded-2xl">
                        <Shield className="h-8 w-8 text-green-500" />
                        <span className="font-semibold text-green-700 dark:text-green-300">Secure & Private</span>
                      </div>
                      <div className="flex flex-col items-center gap-3 p-4 bg-white/50 dark:bg-gray-800/50 rounded-2xl">
                        <Users className="h-8 w-8 text-blue-500" />
                        <span className="font-semibold text-blue-700 dark:text-blue-300">Community Driven</span>
                      </div>
                      <div className="flex flex-col items-center gap-3 p-4 bg-white/50 dark:bg-gray-800/50 rounded-2xl">
                        <Globe className="h-8 w-8 text-purple-500" />
                        <span className="font-semibold text-purple-700 dark:text-purple-300">Real Impact</span>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ) : (
          <>
            {/* Enhanced Hero Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <Card className="bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-blue-600/10 dark:from-blue-500/20 dark:via-cyan-500/20 dark:to-blue-600/20 border-blue-200/50 dark:border-blue-700/50 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 group">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300">
                    <TrendingUp className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-foreground mb-2">Active Issues</h3>
                  <p className="text-muted-foreground text-lg">Being resolved in your area</p>
                  <div className="mt-4 flex items-center justify-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-semibold text-yellow-600 dark:text-yellow-400">Live Updates</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500/10 via-emerald-500/10 to-green-600/10 dark:from-green-500/20 dark:via-emerald-500/20 dark:to-green-600/20 border-green-200/50 dark:border-green-700/50 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 group">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300">
                    <Users className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-foreground mb-2">Community</h3>
                  <p className="text-muted-foreground text-lg">Citizens making a difference</p>
                  <div className="mt-4 flex items-center justify-center gap-2">
                    <Award className="w-4 h-4 text-green-500" />
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">Verified Members</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500/10 via-pink-500/10 to-purple-600/10 dark:from-purple-500/20 dark:via-pink-500/20 dark:to-purple-600/20 border-purple-200/50 dark:border-purple-700/50 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 group">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300">
                    <Sparkles className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-foreground mb-2">Impact</h3>
                  <p className="text-muted-foreground text-lg">Issues resolved this month</p>
                  <div className="mt-4 flex items-center justify-center gap-2">
                    <Globe className="w-4 h-4 text-purple-500" />
                    <span className="text-sm font-semibold text-purple-600 dark:text-purple-400">Global Reach</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Enhanced Main Content Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-8 min-h-[75vh]">
              {/* Issue List - Enhanced Sidebar */}
              <div className="xl:col-span-1 order-2 xl:order-1">
                <Card className="h-full bg-gradient-to-br from-white via-gray-50/50 to-blue-50/30 dark:from-gray-900 dark:via-gray-800/50 dark:to-blue-950/30 shadow-2xl border-0">
                  <IssueList
                    key={refreshKey}
                    userLocation={userLocation}
                    onIssueSelect={setSelectedIssue}
                    selectedIssue={selectedIssue}
                  />
                </Card>
              </div>

              {/* Map - Enhanced Main Content */}
              <div className="xl:col-span-3 order-1 xl:order-2">
                <Card className="h-full overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-700 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800">
                  <div className="relative h-full min-h-[500px] xl:min-h-[75vh]">
                    <Map onIssueSelect={setSelectedIssue} selectedIssue={selectedIssue} userLocation={userLocation} />

                    {/* Enhanced Map Overlay Info */}
                    <div className="absolute top-6 left-6 z-[1000]">
                      <Card className="bg-gradient-to-r from-white/90 via-blue-50/90 to-purple-50/90 dark:from-gray-900/90 dark:via-blue-950/90 dark:to-purple-950/90 backdrop-blur-xl shadow-2xl border-0">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-3 text-lg font-bold">
                            <div className="w-3 h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse shadow-lg"></div>
                            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                              Live Community Map
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Map Stats Overlay */}
                    <div className="absolute bottom-6 right-6 z-[1000]">
                      <Card className="bg-gradient-to-r from-white/90 to-gray-50/90 dark:from-gray-900/90 dark:to-gray-800/90 backdrop-blur-xl shadow-2xl border-0">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                              <span className="font-medium">Open Issues</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              <span className="font-medium">Resolved</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
